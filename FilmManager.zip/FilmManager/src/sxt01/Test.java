package sxt01;

public class Test {
	public static void main(String[] args) {
		FilmManager fm = new FilmManager();
		fm.start();
	}
}
